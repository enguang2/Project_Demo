#define _GNU_SOURCE
#include <dlfcn.h>
#include <pthread.h>
#include <stdbool.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <unistd.h>

/*
 * This macro ensures that only certain symbols are visible to the users of
 * this shared library.
 */
#define EXPORT_SYMBOL __attribute__((__visibility__("default")))

/*
 * These function pointers refer to the original, libc implementations of bind
 */
static int (*real_bind)(int, const struct sockaddr *, socklen_t) = NULL;

/*
 * Load the real versions of malloc and friends and store them in our special
 * function pointers.
 *
 * This function has a reentrancy guard to prevent it from getting stuck in an
 * infinite loop, since dlsym can actually end up calling malloc. In this
 * unusual case, we act like malloc failed by returning false. Otherwise, this
 * function returns true.
 */
static bool load_real_bind(void)
{
    static pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER;
    static __thread bool reentrant_guard = false;

    if (reentrant_guard) {
        return false;
    }
    reentrant_guard = true;
    pthread_mutex_lock(&lock);

    real_bind = (int(*)(int, const struct sockaddr *, socklen_t))
        dlsym(RTLD_NEXT, "bind");

    if (!real_bind) {
        // Can't get the real functions for some reason.
        const char err[] = "FATAL: couldn't resolve libc bind!\n";
        write(STDERR_FILENO, err, sizeof(err));
        exit(3);
    }

    pthread_mutex_unlock(&lock);
    reentrant_guard = false;
    return true;
}

EXPORT_SYMBOL
int bind(int sockfd, const struct sockaddr *addr, socklen_t addrlen)
{
    int ret;
    int optval = 1;

    if (!real_bind && !load_real_bind()) {
        ret = -1;
        goto out;
    }

    ret = setsockopt(sockfd, SOL_SOCKET, SO_REUSEPORT, &optval,
        sizeof(optval));
    if (ret < 0)
        goto out;

    ret = setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR, &optval,
        sizeof(optval));
    if (ret < 0)
        goto out;

    ret = real_bind(sockfd, addr, addrlen);
out:
    return ret;
}
