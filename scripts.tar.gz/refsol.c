// Start with the following code
#include <sys/socket.h>
#include <sys/types.h>
#include <netdb.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <assert.h>
#include <pthread.h>
#include <stdlib.h>
#include <signal.h>
#include <error.h>
#include <errno.h>
#include <math.h>

// author: archnas2 (modified by Jinghao to make it full score)
// Cite all your sources! This is the starting code of the Spring 2022 CS241 Final

// "It's dangerous to go alone, take this!" - Legend of Zelda (1986)
pthread_mutex_t duck = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t time_mtx = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t log_mtx = PTHREAD_MUTEX_INITIALIZER;

#define MAX_CLIENTS 1000
#define REQ_LINES 4

static int clients[MAX_CLIENTS];
static int sock_fd = -1;

void quit(const char *mesg) {
  perror(mesg);
  exit(1);
}

// From Networking MP and Charming Chatrooms Lab
ssize_t read_all_from_socket(int socket, char *buffer, size_t count) {
    size_t offset = 0;

    while (count > 0) {
        int amt_read = read(socket, buffer + offset, count);

        if (amt_read == 0) {
            return amt_read;
        }

        if (amt_read == -1 && errno == EINTR) {
            continue;
        }

        if (amt_read == -1) {
            // return -1; todo: change back?
            continue;
        }

        count -= amt_read;
        offset += amt_read;
    }

    buffer += offset;
    return offset;
}

ssize_t write_all_to_socket(int socket, const char *buffer, size_t count) {
    size_t offset = 0;

    while (count > 0) {
        int sent = write(socket, buffer + offset, count);

        if (sent == 0) {
            return sent;
        }

        if (sent == -1 && errno == EINTR) {
            continue;
        }

        if (sent == -1) {
            return -1;
        }

        count -= sent;
        offset += sent;
    }

    buffer += offset;
    return offset;
}

void* handle_client(void *fd_ptr) {
  pthread_detach(pthread_self()); // pthread_join not needed

  int fd = *(int *) fd_ptr;
  free(fd_ptr);
  fd_ptr = NULL;

  struct sockaddr_in address;
  socklen_t addressLength = sizeof(address);

  int ok = getpeername(fd, (struct sockaddr *) &address, &addressLength);

  // TODO-2: inet_ntoa is not thread-safe! So make this code safe using the duck.
  // inet_ntoa may return a pointer to the same memory location
  // TODO-3: Answer below: If no lock was used to protect this critical section
  // what errors/changes would you expect to see in the programâ€™s behavior or output?

  // The function is not thread safe: inet_ntoa returns a pointer to an array that it maintains,
  // so filename would get overwritten as different threads call on the function
  pthread_mutex_lock(&duck);
  char *filename = ok == 0 ? inet_ntoa(address.sin_addr) : "unknownip";
  // you do not need to call free on the filename

  printf("Logging data to file %s\n", filename);
  FILE *file = fopen(filename, "a+"); // TODO-4 open filename for append;
  pthread_mutex_unlock(&duck);

  char buffer[8 * 1024 + 1];
  memset(buffer, 0, 8 * 1024 + 1);
  size_t numreadtotal = 0;

  // maybe useful later,
  // if (strstr (buffer, "\r\n\r\n")) break
  // fwrite (buffer, 1, , )
  // time_t,  time() and  ctime() are great but look out for thread safety.
  // HTTP request and response headers both use \r\n as a line ending.
  // TODO-5 Prevent a race condition when two threads write to the same log file:
  // - Concurrent requests must not have overlapping content in the log file.

  // Assumption: request header data refers to the entirety of the header

  while (1) {
    // Read data from the socket
    int amt_read = read_all_from_socket(fd, buffer + numreadtotal, 1);

    numreadtotal += amt_read;

    // If no bytes were read, there is nothing else to read, so break out of the loop
    if (strstr(buffer, "\r\n\r\n")) {
        break;
    }

    if (amt_read == 0 || numreadtotal >= (8 * 1024)) {
        break;
    }
  }

  pthread_mutex_lock(&log_mtx);

  // Write all the header to the file
  fwrite(buffer, 1, strlen(buffer), file);
  fclose(file);

  pthread_mutex_unlock(&log_mtx);

  shutdown(fd, SHUT_RD);

  // Send a response header
  write_all_to_socket(fd, "HTTP/1.0 200 OK\r\n", 17);
  write_all_to_socket(fd, "Content-Type: text/plain\r\n", 26);
  write_all_to_socket(fd, "\r\n", 2);

  pthread_mutex_lock(&time_mtx);
  time_t now;
  time(&now);
  char* return_time = ctime(&now);

  write_all_to_socket(fd, return_time, strlen(return_time));
  pthread_mutex_unlock(&time_mtx);

  shutdown(fd, SHUT_WR);

  // Close the connection
  close(fd);

  return 0;
}

// Lab code from Charming Chatrooms
void run_server(char *port) {

    int s;
    sock_fd = socket(AF_INET, SOCK_STREAM, 0);

    struct addrinfo hints, *result;
    memset(&hints, 0, sizeof (struct addrinfo));
    hints.ai_family = AF_INET; /* IPv4 only */
    hints.ai_socktype = SOCK_STREAM; /* TCP */
    hints.ai_flags = AI_PASSIVE;

    s = getaddrinfo(NULL, port, &hints, &result);

    if (s != 0) {
        fprintf(stderr, "getaddrinfo: %s\n", gai_strerror(s));
        freeaddrinfo(result);
        exit(1);
    }

    int optval = 1;
    setsockopt(sock_fd, SOL_SOCKET, SO_REUSEPORT, &optval, sizeof(optval));
    setsockopt(sock_fd, SOL_SOCKET, SO_REUSEADDR, &optval, sizeof(optval));

    if (bind(sock_fd, result->ai_addr, result->ai_addrlen) != 0) {
        freeaddrinfo(result);
        perror(NULL);
        exit(1);
    }

    if (listen(sock_fd, MAX_CLIENTS)) {
        freeaddrinfo(result);
        perror(NULL);
        exit(1);
    }

    pthread_t* pthread = calloc(MAX_CLIENTS, sizeof(pthread_t*));

    size_t i = 0;
    for (i = 0; i < MAX_CLIENTS; i++) {
        clients[i] = -1;
    }

    while (1) {

        int* client_fd = malloc(sizeof(int));

        *(client_fd) = accept(sock_fd, NULL, NULL);

        pthread_t pthread = 0;

        pthread_create(&pthread, NULL, (void*) &handle_client, (void*) client_fd);

    }

    free(pthread);
    freeaddrinfo(result);
}

int main(int argc, char **argv) {
    if (argc != 2) {
        fprintf(stderr, "%s <port>\n", argv[0]);
        return -1;
    }

    run_server(argv[1]);
}
