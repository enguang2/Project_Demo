import asyncio
import datetime
import os
import re
import signal
import subprocess
import sys
import time

src_file = 'honey.c'

def get_date_re():
    d = datetime.date.today()
    weekday = d.strftime('%a')
    month = d.strftime('%b')
    date = d.strftime('%d')
    year = d.strftime('%Y')
    pt = '^.*%s\s*%s\s*%s\s*\d{2}:\d{2}:\d{2}\s*%s.*$' %\
         (weekday, month, date, year)
    return re.compile(pt)

def check_netid(netid):
    # Checks for author line
    with open(src_file) as src:
        content = src.read()

    result = re.match('.*// author:\s*%s.*' % netid, content.replace('\n', ''))
    return result is not None

def check_TCPIPv4():
    # Checks for "socket(AF_INET, SOCK_STREAM" "hints.ai_family = AF_INET" and
    # "hints.ai_socktype = SOCK_STREAM"
    with open(src_file) as src:
        content = src.read()

    result = re.match('.*socket\(AF_INET,\s*SOCK_STREAM.*',
                      content.replace('\n', ''))
    if result is None:
        return False

    result = re.match('.*\.ai_family\s*=\s*AF_INET;.*',
                      content.replace('\n', ''))
    if result is None:
        return False
    result = re.match('.*\.ai_socktype\s*=\s*SOCK_STREAM;.*',
                      content.replace('\n', ''))
    return result is not None

def compile():
    # Whether it compiles
    # clang -O0 -pthread -Wall -Wextra -g -std=c99 -D_GNU_SOURCE -DDEBUG honey.c -L. -lbindshim
    cmd = ('clang -O0 -pthread -Wall -Wextra -g -std=c99 -D_GNU_SOURCE '\
          '-DDEBUG %s -L. -lbindshim' % src_file).split()
    try:
        subprocess.run(cmd, check=True, capture_output=True)
    except subprocess.CalledProcessError as cpe:
        return False
    return True

async def __check_curl():
    # run server
    server_cmd = './a.out 8000'.split()
    server = await asyncio.create_subprocess_exec(*server_cmd)

    # run curl
    curl_cmd = 'curl localhost:8000'.split()
    p = subprocess.run(curl_cmd, capture_output=True)
    output = p.stdout.decode('utf-8').replace('\n', '')

    result = get_date_re().match(output) is not None
    result = result and server.returncode is None

    server.send_signal(signal.SIGKILL)
    await server.wait()

    return result

def check_curl():
    return asyncio.run(__check_curl())

def check_log_name():
    return os.path.exists('127.0.0.1')

def check_log_append():
    check_curl()
    if not check_log_name():
        return False
    with open('127.0.0.1') as log_file:
        content = log_file.read()

    # Check the curl request is logged twice
    return content.count('GET / HTTP/1.1') == 2 and\
           content.count('Host: localhost:8000') == 2 and\
           content.count('User-Agent: curl/7.83.0') == 2 and\
           content.count('Accept: */*') == 2

async def __test_response():
    # run server
    server_cmd = './a.out 8000'.split()
    server = await asyncio.create_subprocess_exec(*server_cmd)

    # Check verbose output on curl side
    curl_cmd = 'curl -v localhost:8000'.split()
    p = subprocess.run(curl_cmd, capture_output=True)
    output = p.stderr.decode('utf-8')
    result = ('HTTP/1.0 200 OK' in output or 'HTTP/1.1 200 OK' in output) and\
             'Content-Type: text/plain' in output
    result = result and server.returncode is None

    server.send_signal(signal.SIGKILL)
    await server.wait()

    return result

def test_response():
    return asyncio.run(__test_response())

def run_test(s, fn, *args):
    # Print case desciption and run test
    print('%s...' % s, end='')
    ret = fn(*args)
    print('\033[01;32mOK\033[00m' if ret\
        else "\033[01;31mFAILED\033[00m")
    return ret

def skip_test(s):
    # Print case desciption that cannot be tested
    print('%s...\033[01;32mNOT TESTED\033[00m'\
          '(Please read the source code manually)' % s)

def main(argv):
    netid = argv[1]
    score = 0
    score += 10 if run_test('Author line includes your netid',
                            check_netid, netid) else 0
    score += 10 if run_test('Creates a TCP/IPv4 server on the specified port',
                            check_TCPIPv4) else 0
    skip_test('Uses pthreads to concurrently accept and '\
              'process multiple concurrent requests')
    skip_test('Code comment explains the possible result(s) of '\
              'a missing lock on inet_ntoa’s critical section')
    compile()
    score += 10 if run_test('When tested with a client (e.g. curl), client '\
                            'displays the current date & time as the response',
                            check_curl) else 0
    score += 10 if run_test('Client data is stored in a file where the '\
                            'filename is the connecting client’s IPv4 octet '\
                            'address', check_log_name) else 0
    score += 10 if run_test('Appends the request headers to a log file',
                            check_log_append) else 0
    score += 10 if run_test('Response is a valid HTTP response with the '\
                            'correct MIME type.', test_response) else 0
    skip_test('Critical sections (e.g. ctime, inet_ntoa, and logging) are '\
              'protected against race conditions')
    skip_test('Reads headers (up to 8KB of data) that arrive over multiple '\
              'calls to read()')
    print("%d/60" % score)

if __name__ == '__main__':
    main(sys.argv)
